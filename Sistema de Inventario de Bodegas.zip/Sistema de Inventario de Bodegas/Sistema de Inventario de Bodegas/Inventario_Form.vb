﻿Public Class Inventario_Form
    Private Sub InventarioBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.InventarioBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me._Inv_Bodegas_DataSet)
        Guardar_Inventario.Visible = False
        Nuevo_Inventario.Visible = False
        Eliminar_Inventario.Visible = False
        Cancelar_Operacion.Visible = False
        IdInventarioTextBox.Enabled = False
        IdProductoTextBox.Enabled = False
        MedidaComboBox.Enabled = False
        IdBodegaComboBox.Enabled = False
        Existencia_InicialTextBox.Enabled = False
        Existencia_FinalTextBox.Enabled = False
        Editar_Button_inventario.Enabled = True
    End Sub

    Private Sub Inventario_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the '_Inv_Bodegas_DataSet.Producto' table. You can move, or remove it, as needed.
        Me.ProductoTableAdapter.Fill(Me._Inv_Bodegas_DataSet.Producto)
        'TODO: This line of code loads data into the '_Inv_Bodegas_DataSet.Inventario' table. You can move, or remove it, as needed.
        Me.InventarioTableAdapter.Fill(Me._Inv_Bodegas_DataSet.Inventario)

    End Sub

    Private Sub Salir_Button_Inventario_Click(sender As Object, e As EventArgs) Handles Salir_Button_inventario.Click
        Me.Close()
        Menu_Form.Show()
    End Sub

    Private Sub Editar_Button_Inventario_Click(sender As Object, e As EventArgs) Handles Editar_Button_inventario.Click
        Guardar_Inventario.Visible = True
        Nuevo_Inventario.Visible = True
        Eliminar_Inventario.Visible = True
        Cancelar_Operacion.Visible = True
        IdInventarioTextBox.Enabled = True
        IdProductoTextBox.Enabled = True
        MedidaComboBox.Enabled = True
        IdBodegaComboBox.Enabled = True
        Existencia_InicialTextBox.Enabled = True
        Existencia_FinalTextBox.Enabled = True
        Editar_Button_inventario.Enabled = False


    End Sub

    Private Sub Cancelar_Operacion_Click(sender As Object, e As EventArgs) Handles Cancelar_Operacion.Click
        Guardar_Inventario.Visible = False
        Nuevo_Inventario.Visible = False
        Eliminar_Inventario.Visible = False
        Cancelar_Operacion.Visible = False
        IdInventarioTextBox.Enabled = False
        IdProductoTextBox.Enabled = False
        MedidaComboBox.Enabled = False
        IdBodegaComboBox.Enabled = False
        Existencia_InicialTextBox.Enabled = False
        Existencia_FinalTextBox.Enabled = False
        Editar_Button_inventario.Enabled = True
    End Sub
End Class