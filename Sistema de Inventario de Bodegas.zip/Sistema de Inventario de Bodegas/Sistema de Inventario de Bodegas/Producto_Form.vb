﻿Public Class Producto_Form

    Private Sub Salir_Button_Click(sender As Object, e As EventArgs) Handles Salir_Button.Click
        Me.Close()
    End Sub

    Private Sub ProductoBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        'Me.Validate()
        'Me.ProductoBindingSource.EndEdit()
        'Me.TableAdapterManager.UpdateAll(Me.Inv - Bodegas_DataSet)
    End Sub

    Private Sub Producto_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the '_Inv_Bodegas_DataSet.Producto' table. You can move, or remove it, as needed.
        Me.ProductoTableAdapter.Fill(Me._Inv_Bodegas_DataSet.Producto)
        'TODO: This line of code loads data into the 'DataSet11.Producto' table. You can move, or remove it, as needed.
        'TODO: This line of code loads data into the 'DataSet1.Producto' table. You can move, or remove it, as needed.
        'Me.ProductoTableAdapter.Fill(Me.Inv-Bodegas_DataSet.Producto)
    End Sub

    Private Sub ProductoBindingNavigatorSaveItem_Click_1(sender As Object, e As EventArgs) Handles Guardar_Producto.Click
        Me.Validate()
        Me.ProductoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me._Inv_Bodegas_DataSet)
        Guardar_Producto.Visible = False
        Nuevo_Producto.Visible = False
        Eliminar_Producto.Visible = False
        Cancelar_Producto.Visible = False
        IdProductoTextBox.Enabled = False
        NombreTextBox.Enabled = False
        MarcaTextBox.Enabled = False
        EstadoComboBox.Enabled = False
        TipoComboBox.Enabled = False
        Editar_Button.Enabled = True
    End Sub

    Private Sub Editar_Button_Click(sender As Object, e As EventArgs) Handles Editar_Button.Click
        Nuevo_Producto.Visible = True
        Eliminar_Producto.Visible = True
        Guardar_Producto.Visible = True
        Cancelar_Producto.Visible = True
        IdProductoTextBox.Enabled = True
        NombreTextBox.Enabled = True
        MarcaTextBox.Enabled = True
        EstadoComboBox.Enabled = True
        TipoComboBox.Enabled = True
        Editar_Button.Enabled = False
    End Sub

    Private Sub Cancelar_Producto_Click(sender As Object, e As EventArgs) Handles Cancelar_Producto.Click
        Guardar_Producto.Visible = False
        Nuevo_Producto.Visible = False
        Eliminar_Producto.Visible = False
        Cancelar_Producto.Visible = False
        IdProductoTextBox.Enabled = False
        NombreTextBox.Enabled = False
        MarcaTextBox.Enabled = False
        EstadoComboBox.Enabled = False
        TipoComboBox.Enabled = False
        Editar_Button.Enabled = True
    End Sub

End Class